Welcome to Stripe Invoice Template
==================================
This a super simple PHP invoice template for a Stripe invoice object built using Twitter's Bootstrap. 


* Author:    Patrick Talmadge
* Date:      April 4, 2012
* Last mod.: April 4, 2012
* Version:   0.5.0
* Website:   <http://patricktalmadge.github.com/Bootstrap-Stripe-Invoice-Template/>
* GitHub:    <https://github.com/patricktalmadge/Bootstrap-Stripe-Invoice-Template>
* Twitter: 	 <http://twitter.com/patricktalmadge>


Configure 
=========

Change the following variable to match your Stripe account keys.
$stripeKey = "{PRIVATE_KEY}";

I had $invoiceID hard coded for a sample you should change this value to meet your needs.

$invoiceID = 'in_123456789';

i.e $invoiceID = $_GET["id"] if you want a url like http://www.xyz.com/invoice.php?id=in_123456789 
    