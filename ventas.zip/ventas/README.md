# Inventio Lite
Inventio Lite es un sistema de Inventario y Ventas de proposito general desarrollado con PHP y MySQL.

## Modulos
- Productos
- Categorias
- Caja
- Clientes
- Proveedores
- Inventario
- Usuarios

## Mas informacion
Encuentra mas informacion, instrucciones y demos en el siguiente link.
Link: http://evilnapsis.com/2015/07/11/inventio-lite-sistema-de-inventario-y-ventas/