<html>
<head>
	<title>Login Sistema Crédito</title>
</head>
<body>

<form action="login.php" method="post">
		Username: <input type="text" name="usuario" /><br />
		Password: <input type="password" name="clave" /><br />
 
		<input type="submit" name="submit" value="Login" />
</form>

</body>
</html>