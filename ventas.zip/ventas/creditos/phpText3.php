<?php 
$resultado = 30; 
echo $resultado;
?>