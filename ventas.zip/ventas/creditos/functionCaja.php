<?php

function caja($montoInicial, $ingresosEfectivo, $gastosEfectivo, $apartadoEnCaja, $efectivoEnCaja)
{
return ($montoInicial+ $ingresosEfectivo - $gastosEfectivo - $apartadoEnCaja);
}

?>
