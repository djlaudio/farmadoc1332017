<?php



$cargarFacturasEnfermedadCliente="select * from sell wehere person_id= and idDisease=";

?>